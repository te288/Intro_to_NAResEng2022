def hello():
    print("Laboratory Of Geothermics")
    return

def Qubic(a):
    Q = a**3
    return Q
    