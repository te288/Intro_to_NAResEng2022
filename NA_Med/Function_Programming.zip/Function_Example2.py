def Area(L, W):
    S = L*W
    return S